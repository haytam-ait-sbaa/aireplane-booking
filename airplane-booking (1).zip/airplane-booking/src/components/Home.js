import React, { useState } from 'react';
import {
  Container,
  Paper,
  Typography,
  TextField,
  Button,
  Grid,
  Box,
  Autocomplete
} from '@mui/material';
import { AdapterDateFns } from '@mui/x-date-pickers/AdapterDateFns';
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import { DatePicker } from '@mui/x-date-pickers/DatePicker';

const airports = [
  { label: 'Paris (CDG)', code: 'CDG' },
  { label: 'New York (JFK)', code: 'JFK' },
  { label: 'London (LHR)', code: 'LHR' },
  { label: 'Tokyo (HND)', code: 'HND' },
];

const Home = () => {
  const [searchData, setSearchData] = useState({
    departure: null,
    arrival: null,
    departureDate: null,
    returnDate: null,
    passengers: 1
  });

  const handleSearch = () => {
    console.log('Search flights:', searchData);
  };

  return (
    <Container maxWidth="md" sx={{ mt: 4 }}>
      <Paper elevation={3} sx={{ p: 4 }}>
        <Typography variant="h4" gutterBottom align="center">
          Réservation de Vols
        </Typography>
        
        <Box component="form" sx={{ mt: 3 }}>
          <Grid container spacing={3}>
            <Grid item xs={12} md={6}>
              <Autocomplete
                options={airports}
                getOptionLabel={(option) => option.label}
                renderInput={(params) => (
                  <TextField
                    {...params}
                    label="Départ"
                    required
                    fullWidth
                  />
                )}
                onChange={(_, value) => setSearchData({ ...searchData, departure: value })}
              />
            </Grid>
            
            <Grid item xs={12} md={6}>
              <Autocomplete
                options={airports}
                getOptionLabel={(option) => option.label}
                renderInput={(params) => (
                  <TextField
                    {...params}
                    label="Arrivée"
                    required
                    fullWidth
                  />
                )}
                onChange={(_, value) => setSearchData({ ...searchData, arrival: value })}
              />
            </Grid>

            <Grid item xs={12} md={6}>
              <LocalizationProvider dateAdapter={AdapterDateFns}>
                <DatePicker
                  label="Date de départ"
                  value={searchData.departureDate}
                  onChange={(newValue) => setSearchData({ ...searchData, departureDate: newValue })}
                  renderInput={(params) => <TextField {...params} fullWidth required />}
                />
              </LocalizationProvider>
            </Grid>

            <Grid item xs={12} md={6}>
              <LocalizationProvider dateAdapter={AdapterDateFns}>
                <DatePicker
                  label="Date de retour"
                  value={searchData.returnDate}
                  onChange={(newValue) => setSearchData({ ...searchData, returnDate: newValue })}
                  renderInput={(params) => <TextField {...params} fullWidth />}
                />
              </LocalizationProvider>
            </Grid>

            <Grid item xs={12} md={6}>
              <TextField
                type="number"
                label="Nombre de passagers"
                value={searchData.passengers}
                onChange={(e) => setSearchData({ ...searchData, passengers: e.target.value })}
                InputProps={{ inputProps: { min: 1, max: 9 } }}
                fullWidth
              />
            </Grid>

            <Grid item xs={12}>
              <Button
                variant="contained"
                color="primary"
                size="large"
                fullWidth
                onClick={handleSearch}
              >
                Rechercher des vols
              </Button>
            </Grid>
          </Grid>
        </Box>
      </Paper>
    </Container>
  );
};

export default Home;
