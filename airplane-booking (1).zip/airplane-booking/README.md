# Application de Réservation de Vols

Cette application web permet aux utilisateurs de rechercher et réserver des vols en ligne.

## Fonctionnalités

- Inscription et connexion des utilisateurs
- Recherche de vols avec critères multiples
- Interface utilisateur moderne et responsive

## Installation

1. Clonez le repository
2. Installez les dépendances :
```bash
npm install
```

## Démarrage

Pour lancer l'application en mode développement :
```bash
npm start
```

L'application sera accessible à l'adresse [http://localhost:3000](http://localhost:3000)

## Technologies utilisées

- React.js
- Material-UI
- React Router
- Axios pour les requêtes HTTP
